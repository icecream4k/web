<template>
    <div id="wrap">
        <router-link to="/home" tag="button">首页</router-link>
        <div class="innerdemo">

        </div>
    </div>
</template>
<script>
    export default {
        name: 'AvoidCompilation'
    };
</script>
<style lang='less'>
    @import "../../styles/AvoidCompilation.less";
</style>