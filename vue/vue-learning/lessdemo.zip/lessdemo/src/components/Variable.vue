<template>
    <div id="wrap">
        <router-link to="/Home" tag="button">首页</router-link>
        <div class="inner"></div>
    </div>
</template>
<script>
    export default {
        name: 'Variable'
    };
</script>
<style lang='less'>
    @import "../../styles/Variable.less";
</style>