var todoItem = {
    props:['t','i'],
    template:`
    <li class='todo-item'>
        {{i+1}} - {{t}}<a href='javascript:;'>X</a>
    </li>
    `
}