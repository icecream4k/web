import Constructor from './instance/constructor'

Constructor()

export default Constructor
